class Forum < ApplicationRecord
end
