class Twerp < ApplicationRecord
end
