# Assignment C - Part 2: GitHub Codemates Group Work

Details for this assignment are in bCourses: https://bcourses.berkeley.edu/courses/1516114/assignments/8444144
