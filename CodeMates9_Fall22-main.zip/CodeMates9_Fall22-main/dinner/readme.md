Juicy, (Not)Beefy Burger

## Servings: 
5 servings

## Time to prepare: 
20 minutes
## Ingredients:

5 Beyond Burgers

1 head of Iceberg or Butter Lettuce

1 large white onion

1 large tomato

2-4 slices of plant-based cheddar cheese

2 tbsp. of plant-based special sauce (1000 island)

1 tsp. Seasoning of your choice (optional)

6 pickles


## Equipment needed:

Griddle pan or skillet

Salt and pepper grinders

Meat thermometer

Spatula

Burger press

Favorite burger recipe

Apron

Cutting Board

Plate for your burger

## Steps for preparation:

Pre-heat grill. Place a grill-safe pan on one side of the grill. 

While the grill is heating up, prep burger toppings. Separate lettuce leaves into bun-sized pieces, thickly slice tomatoes, and dice the onion. 

Add your chopped onions to the grill pan mixing in some cooking oil as needed. Cook until softened and translucent, mixing frequently to avoid burning. Once these are cooked, remove from the grill. 

Next, grill the Beyond Burger patties for about 4 minutes on each side. At the last minute add a slice of plant-based cheddar cheese, and cover. 

Build your burger - place a cooked Beyond Burger on a bed of lettuce, top with a second Beyond Burger, grilled onions, two tomato slices, plant-based special sauce, and more lettuce. 

Enjoy!


### Notes:

Goals: Prepare a yummy and juicy dinner! 



### Codemates #
